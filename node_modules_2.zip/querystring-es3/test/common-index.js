"use strict";

require("test").run(require("./index"))