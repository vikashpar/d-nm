# Angular Foundation

This repo is solely a release distribution point for `npm` and `bower`. For the main development repository for this project, see [https://github.com/pineconellc/angular-foundation](https://github.com/pineconellc/angular-foundation).

Angular Foundation comes in several flavors:

* `mm-foundation-tpls-VERSION.js` **with** templates
* `mm-foundation-VERSION.js` **without** templates
* `mm-foundation-tpls-VERSION.min.js` minified **with** templates
* `mm-foundation-VERSION.min.js` minified **without** templates

You can view the release changelog [here](https://github.com/pineconellc/angular-foundation/blob/master/CHANGELOG.md).
